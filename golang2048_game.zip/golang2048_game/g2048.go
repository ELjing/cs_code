package main

import "g2048"

func main(){
	var game g2048.G2048
	game.Run()
}

